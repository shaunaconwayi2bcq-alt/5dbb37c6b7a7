// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Render halcyon calm\n", stdout);
  return lionss_run_workload("Halcyon");
}
