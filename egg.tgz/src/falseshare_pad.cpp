// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Measure false sharing\n", stdout);
  return lionss_run_workload("falseshare_pad");
}
