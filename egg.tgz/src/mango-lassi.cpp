// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Blend mango lassi\n", stdout);
  return lionss_run_workload("mango-lassi");
}
