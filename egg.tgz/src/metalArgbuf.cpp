// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode argument buffer"); }
int main(){
  announce();
  return lionss_run_workload("metalArgbuf");
}
