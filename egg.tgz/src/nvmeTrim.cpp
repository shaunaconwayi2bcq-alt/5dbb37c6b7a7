// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Trim unused blocks\n", stdout);
  return lionss_run_workload("nvmeTrim");
}
