// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Return from machine trap\n", stdout);
  return lionss_run_workload("riscv-mret");
}
