# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(riscv-mret src/riscv-mret.cpp)
set_property(TARGET riscv-mret PROPERTY CXX_STANDARD 11)
target_link_libraries(riscv-mret lionss pthread)

add_executable(modbuscrc src/modbuscrc.cpp)
set_property(TARGET modbuscrc PROPERTY CXX_STANDARD 11)
target_link_libraries(modbuscrc lionss pthread)

add_executable(coap-observe src/coap-observe.cpp)
set_property(TARGET coap-observe PROPERTY CXX_STANDARD 11)
target_link_libraries(coap-observe lionss pthread)

add_executable(palegold src/palegold.cpp)
set_property(TARGET palegold PROPERTY CXX_STANDARD 11)
target_link_libraries(palegold lionss pthread)

add_executable(RagdollTune src/RagdollTune.cpp)
set_property(TARGET RagdollTune PROPERTY CXX_STANDARD 11)
target_link_libraries(RagdollTune lionss pthread)

add_executable(zonemapskip src/zonemapskip.cpp)
set_property(TARGET zonemapskip PROPERTY CXX_STANDARD 11)
target_link_libraries(zonemapskip lionss pthread)

add_executable(mango-lassi src/mango-lassi.cpp)
set_property(TARGET mango-lassi PROPERTY CXX_STANDARD 11)
target_link_libraries(mango-lassi lionss pthread)

add_executable(raid-resync src/raid-resync.cpp)
set_property(TARGET raid-resync PROPERTY CXX_STANDARD 11)
target_link_libraries(raid-resync lionss pthread)

add_executable(SnapshotBless src/SnapshotBless.cpp)
set_property(TARGET SnapshotBless PROPERTY CXX_STANDARD 11)
target_link_libraries(SnapshotBless lionss pthread)

add_executable(loudness_lufs src/loudness_lufs.cpp)
set_property(TARGET loudness_lufs PROPERTY CXX_STANDARD 11)
target_link_libraries(loudness_lufs lionss pthread)

add_executable(malachite src/malachite.cpp)
set_property(TARGET malachite PROPERTY CXX_STANDARD 11)
target_link_libraries(malachite lionss pthread)

add_executable(curve_ladder src/curve_ladder.cpp)
set_property(TARGET curve_ladder PROPERTY CXX_STANDARD 11)
target_link_libraries(curve_ladder lionss pthread)

add_executable(nvmeTrim src/nvmeTrim.cpp)
set_property(TARGET nvmeTrim PROPERTY CXX_STANDARD 11)
target_link_libraries(nvmeTrim lionss pthread)

add_executable(pacinggain src/pacinggain.cpp)
set_property(TARGET pacinggain PROPERTY CXX_STANDARD 11)
target_link_libraries(pacinggain lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(Halcyon src/Halcyon.cpp)
set_property(TARGET Halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(Halcyon lionss pthread)

add_executable(snp-call src/snp-call.cpp)
set_property(TARGET snp-call PROPERTY CXX_STANDARD 11)
target_link_libraries(snp-call lionss pthread)

add_executable(pitchShift2x src/pitchShift2x.cpp)
set_property(TARGET pitchShift2x PROPERTY CXX_STANDARD 11)
target_link_libraries(pitchShift2x lionss pthread)

add_executable(falseshare_pad src/falseshare_pad.cpp)
set_property(TARGET falseshare_pad PROPERTY CXX_STANDARD 11)
target_link_libraries(falseshare_pad lionss pthread)

add_executable(ambisonicb src/ambisonicb.cpp)
set_property(TARGET ambisonicb PROPERTY CXX_STANDARD 11)
target_link_libraries(ambisonicb lionss pthread)

add_executable(mux9 src/mux9.cpp)
set_property(TARGET mux9 PROPERTY CXX_STANDARD 11)
target_link_libraries(mux9 lionss pthread)

add_executable(wasmSimd128 src/wasmSimd128.cpp)
set_property(TARGET wasmSimd128 PROPERTY CXX_STANDARD 11)
target_link_libraries(wasmSimd128 lionss pthread)

add_executable(quokka7 src/quokka7.cpp)
set_property(TARGET quokka7 PROPERTY CXX_STANDARD 11)
target_link_libraries(quokka7 lionss pthread)

add_executable(metalArgbuf src/metalArgbuf.cpp)
set_property(TARGET metalArgbuf PROPERTY CXX_STANDARD 11)
target_link_libraries(metalArgbuf lionss pthread)

add_executable(duskfall src/duskfall.cpp)
set_property(TARGET duskfall PROPERTY CXX_STANDARD 11)
target_link_libraries(duskfall lionss pthread)

add_executable(tlsResume src/tlsResume.cpp)
set_property(TARGET tlsResume PROPERTY CXX_STANDARD 11)
target_link_libraries(tlsResume lionss pthread)

add_executable(gradclip-norm src/gradclip-norm.cpp)
set_property(TARGET gradclip-norm PROPERTY CXX_STANDARD 11)
target_link_libraries(gradclip-norm lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(ecn_mark src/ecn_mark.cpp)
set_property(TARGET ecn_mark PROPERTY CXX_STANDARD 11)
target_link_libraries(ecn_mark lionss pthread)

add_executable(harrier src/harrier.cpp)
set_property(TARGET harrier PROPERTY CXX_STANDARD 11)
target_link_libraries(harrier lionss pthread)

